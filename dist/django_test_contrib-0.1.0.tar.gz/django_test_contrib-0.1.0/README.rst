A test package for adding a package to Django contrib
