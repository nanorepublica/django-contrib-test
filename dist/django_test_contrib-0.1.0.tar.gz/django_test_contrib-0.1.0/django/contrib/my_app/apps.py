
from django.apps import AppConfig


class MyAppConfig(AppConfig):
    name = "django.contrib.my_app"
